// src/services/salesService.ts
import {
  collection,
  addDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  Timestamp,
  DocumentData,
  serverTimestamp,
} from 'firebase/firestore';
// IMPORTANT: make this match your other services (../firebase or ../firebaseConfig)
import { db } from '../firebase';

const SALES_COLLECTION = 'sales';

export type Sale = {
  id?: string;
  productId?: string;
  productName?: string;
  quantity?: number;
  total?: number;
  customerPhone?: string;
  customerName?: string;
  createdAt?: Timestamp;
};

const salesCol = collection(db, SALES_COLLECTION);

// Used by Sales screen to create a sale
export async function addSale(
  sale: Omit<Sale, 'id' | 'createdAt'>
) {
  const docRef = await addDoc(salesCol, {
    ...sale,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

// 3‑month total for Sales overview/Home
export async function getThreeMonthSalesTotal(): Promise<number> {
  const now = new Date();
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(now.getMonth() - 3);

  const q = query(
    salesCol,
    where('createdAt', '>=', Timestamp.fromDate(threeMonthsAgo)),
  );

  const snapshot = await getDocs(q);

  let total = 0;

  snapshot.forEach(docSnap => {
    const data = docSnap.data() as DocumentData;
    const amount = data.total;
    if (typeof amount === 'number') {
      total += amount;
    }
  });

  return total;
}

// Recent N sales for overview block
export async function getRecentSales(limitCount = 3): Promise<Sale[]> {
  const q = query(salesCol, orderBy('createdAt', 'desc'), limit(limitCount));

  const snapshot = await getDocs(q);
  const result: Sale[] = [];

  snapshot.forEach(docSnap => {
    const data = docSnap.data() as DocumentData;
    result.push({
      id: docSnap.id,
      productId: data.productId,
      productName: data.productName,
      quantity: data.quantity,
      total: data.total,
      customerPhone: data.customerPhone,
      customerName: data.customerName,
      createdAt: data.createdAt as Timestamp,
    });
  });

  return result;
}