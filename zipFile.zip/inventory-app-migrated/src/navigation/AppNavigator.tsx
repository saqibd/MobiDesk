// src/navigation/AppNavigator.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/HomeScreen';
import SalesScreen from '../screens/SalesScreen';
import InventoryScreen from '../screens/InventoryScreen';
import CustomersScreen from '../screens/CustomersScreen';
import ReportsScreen from '../screens/ReportsScreen';
import AddProductScreen from '../screens/AddProductScreen';
import ScanBarcodeScreen from '../screens/ScanBarcodeScreen';
import SalesHistoryScreen from '../screens/SalesHistoryScreen';
import CustomerSelectScreen from '../screens/CustomerSelectScreen';
import ProductSelectScreen from '../screens/ProductSelectScreen';
import ReviewOrderScreen from '../screens/ReviewOrderScreen';
import AddCustomerScreen from '../screens/AddCustomerScreen';

export type RootStackParamList = {
  Home: undefined;
  Sales:
    | {
        selectedCustomerName?: string;
        selectedCustomerPhone?: string;
        selectedProductId?: string;
        selectedProductName?: string;
        selectedProductPrice?: number;
        selectedProductStock?: number;
      }
    | undefined;
  Inventory: undefined;
  Customers: undefined;
  Reports: undefined;
  AddProduct: { scannedBarcode?: string } | undefined;
  ScanBarcode: undefined;
  SalesHistory: undefined;
  AddCustomer: undefined;
  CustomerSelect:
    | {
        returnTo?: 'Sales';
      }
    | undefined;
  ProductSelect:
    | {
        returnTo?: 'Sales';
      }
    | undefined;
  ReviewOrder: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        {/* Dashboard */}
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Mobile Inventory Dashboard' }}
        />

        {/* Main sections */}
        <Stack.Screen
          name="Sales"
          component={SalesScreen}
          options={{ title: 'Sales' }}
        />
        <Stack.Screen
          name="Inventory"
          component={InventoryScreen}
          options={{ title: 'Inventory Management' }}
        />
        <Stack.Screen
          name="Customers"
          component={CustomersScreen}
          options={{ title: 'Customer Management' }}
        />
        <Stack.Screen
          name="Reports"
          component={ReportsScreen}
          options={{ title: 'Reports' }}
        />
        <Stack.Screen
          name="AddProduct"
          component={AddProductScreen}
          options={{ title: 'Add Product' }}
        />
        <Stack.Screen
          name="ScanBarcode"
          component={ScanBarcodeScreen}
          options={{ title: 'Scan Barcode' }}
        />
        <Stack.Screen
	  name="AddCustomer"
	  component={AddCustomerScreen}
	  options={{ title: 'Add Customer' }}
	/>
        <Stack.Screen
          name="SalesHistory"
          component={SalesHistoryScreen}
          options={{ title: 'Sales History' }}
        />

        {/* Sales helpers */}
        <Stack.Screen
          name="CustomerSelect"
          component={CustomerSelectScreen}
          options={{ title: 'Select Customer' }}
        />
        <Stack.Screen
          name="ProductSelect"
          component={ProductSelectScreen}
          options={{ title: 'Select Product' }}
        />
        <Stack.Screen
          name="ReviewOrder"
          component={ReviewOrderScreen}
          options={{ title: 'Review Order' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}