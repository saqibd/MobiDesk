// src/screens/HomeScreen.tsx
import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../App';
import {
  getProductStats,
  getProducts,
  type ProductStats,
} from '../services/productService';
import type { ProductWithId as Product } from '../types/product';
import { getThreeMonthSalesTotal } from '../services/salesService';
import { getPendingOrdersCount } from '../services/ordersService';
import { getActiveRemindersCount } from '../services/remindersService'; // <-- added

type HomeNavProp = NativeStackNavigationProp<RootStackParamList, 'Home'>;

export default function HomeScreen() {
  const navigation = useNavigation<HomeNavProp>();
  const [search, setSearch] = useState('');
  const [stats, setStats] = useState<ProductStats | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingStats, setLoadingStats] = useState(false);
  const [loadingProducts, setLoadingProducts] = useState(false);

  // 3‑month sales state
  const [threeMonthSales, setThreeMonthSales] = useState<number | null>(null);
  const [loadingThreeMonthSales, setLoadingThreeMonthSales] =
    useState(false);

  // Pending orders state
  const [pendingOrdersCount, setPendingOrdersCount] = useState<number | null>(
    null,
  );
  const [loadingPendingOrders, setLoadingPendingOrders] = useState(false);

  // Reminders state
  const [remindersCount, setRemindersCount] = useState<number | null>(null);
  const [loadingReminders, setLoadingReminders] = useState(false);

  const goToSales = () => navigation.navigate('Sales');
  const goToInventory = () => navigation.navigate('Inventory');
  const goToCustomers = () => navigation.navigate('Customers');
  const goToReports = () => navigation.navigate('Reports');

  // Load stats, products, 3‑month sales, pending orders, and reminders once
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoadingStats(true);
        setLoadingProducts(true);
        setLoadingThreeMonthSales(true);
        setLoadingPendingOrders(true);
        setLoadingReminders(true);

        const [
          statsResult,
          productsResult,
          threeMonthSalesTotal,
          pendingOrders,
          activeReminders,
        ] = await Promise.all([
          getProductStats(),
          getProducts(),
          getThreeMonthSalesTotal(),
          getPendingOrdersCount(),
          getActiveRemindersCount(),
        ]);

        setStats(statsResult);
        setProducts(productsResult);
        setThreeMonthSales(threeMonthSalesTotal);
        setPendingOrdersCount(pendingOrders);
        setRemindersCount(activeReminders);
      } catch (error) {
        console.error('Error loading dashboard data', error);
        // Fallbacks so UI does not stay null
        setThreeMonthSales(prev => prev ?? 0);
        setPendingOrdersCount(prev => prev ?? 0);
        setRemindersCount(prev => prev ?? 0);
      } finally {
        setLoadingStats(false);
        setLoadingProducts(false);
        setLoadingThreeMonthSales(false);
        setLoadingPendingOrders(false);
        setLoadingReminders(false);
      }
    };

    loadData();
  }, []);

  const filteredProducts = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return [];
    return products.filter(p => {
      const name = p.name?.toLowerCase() ?? '';
      const barcode = p.barcode?.toLowerCase() ?? '';
      const sku = p.sku?.toLowerCase() ?? '';
      return (
        name.includes(term) ||
        barcode.includes(term) ||
        sku.includes(term)
      );
    });
  }, [search, products]);

  const formatCurrency = (value: number) => {
    if (!value) return 'PKR 0';
    return `PKR ${value.toLocaleString('en-PK', {
      maximumFractionDigits: 0,
    })}`;
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Mobile Inventory System</Text>
        <Text style={styles.subtitle}>
          Dashboard overview of your shop
        </Text>

        {/* Search bar */}
        <View style={styles.searchWrapper}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search products by name, SKU, barcode..."
            value={search}
            onChangeText={setSearch}
          />
        </View>

        {/* Search results (products) */}
        {search.trim().length > 0 && (
          <View style={styles.searchResultsBox}>
            {loadingProducts ? (
              <View style={styles.centerRow}>
                <ActivityIndicator size="small" />
                <Text style={styles.searchStatusText}>
                  Loading products...
                </Text>
              </View>
            ) : filteredProducts.length === 0 ? (
              <Text style={styles.searchStatusText}>
                No matches found.
              </Text>
            ) : (
              filteredProducts.slice(0, 10).map(p => (
                <View key={p.id} style={styles.searchItem}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.searchItemName}>{p.name}</Text>
                    <Text style={styles.searchItemSub}>
                      {p.barcode || 'No barcode'} · Stock: {p.stock ?? 0}
                    </Text>
                  </View>
                </View>
              ))
            )}
          </View>
        )}

        {/* Navigation buttons */}
        <View style={styles.navRow}>
          <TouchableOpacity style={styles.navCard} onPress={goToSales}>
            <Text style={styles.navTitle}>Sales</Text>
            <Text style={styles.navSubtitle}>New sale, history</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.navCard} onPress={goToInventory}>
            <Text style={styles.navTitle}>Inventory</Text>
            <Text style={styles.navSubtitle}>Stock & products</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.navRow}>
          <TouchableOpacity style={styles.navCard} onPress={goToCustomers}>
            <Text style={styles.navTitle}>Customers</Text>
            <Text style={styles.navSubtitle}>Manage customer data</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.navCard} onPress={goToReports}>
            <Text style={styles.navTitle}>Reports</Text>
            <Text style={styles.navSubtitle}>Sales & stock reports</Text>
          </TouchableOpacity>
        </View>

        {/* Summary cards */}
        <Text style={styles.sectionTitle}>Summary</Text>

        {loadingStats && !stats ? (
          <View style={styles.centerRow}>
            <ActivityIndicator size="small" />
            <Text style={styles.summaryLoadingText}>Loading stats...</Text>
          </View>
        ) : (
          <View style={styles.summaryGrid}>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>Total stock</Text>
              <Text style={styles.summaryValue}>
                {stats ? `${stats.totalStock} items` : '0 items'}
              </Text>
            </View>

            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>Stock value</Text>
              <Text style={styles.summaryValue}>
                {stats ? formatCurrency(stats.stockValue) : 'PKR 0'}
              </Text>
            </View>

            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>Low stock items</Text>
              <Text style={styles.summaryValue}>
                {stats ? stats.lowStockCount : 0}
              </Text>
            </View>

            {/* 3‑month sales from Firestore */}
            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>3‑month sales</Text>
              <Text style={styles.summaryValue}>
                {loadingThreeMonthSales || threeMonthSales === null
                  ? '...'
                  : formatCurrency(threeMonthSales)}
              </Text>
            </View>

            {/* Pending orders from Firestore */}
            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>Pending orders</Text>
              <Text style={styles.summaryValue}>
                {loadingPendingOrders || pendingOrdersCount === null
                  ? '...'
                  : pendingOrdersCount}
              </Text>
            </View>

            {/* Reminders from Firestore */}
            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>Reminders</Text>
              <Text style={styles.summaryValue}>
                {loadingReminders || remindersCount === null
                  ? '...'
                  : `${remindersCount} active`}
              </Text>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  container: {
    padding: 16,
    paddingBottom: 24,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#555',
    textAlign: 'center',
    marginBottom: 16,
  },
  searchWrapper: {
    marginBottom: 8,
  },
  searchInput: {
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  searchResultsBox: {
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 12,
  },
  searchStatusText: {
    fontSize: 13,
    color: '#666',
  },
  searchItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    borderBottomWidth: 0.5,
    borderBottomColor: '#eee',
  },
  searchItemName: {
    fontSize: 14,
    fontWeight: '600',
  },
  searchItemSub: {
    fontSize: 12,
    color: '#666',
  },
  centerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 8,
  },
  navRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  navCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 4,
    elevation: 2,
  },
  navTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  navSubtitle: {
    fontSize: 12,
    color: '#666',
  },
  sectionTitle: {
    marginTop: 16,
    marginBottom: 8,
    fontSize: 16,
    fontWeight: '600',
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -4,
  },
  summaryCard: {
    width: '50%',
    paddingHorizontal: 4,
    marginBottom: 8,
  },
  summaryLabel: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    fontSize: 13,
    color: '#444',
  },
  summaryValue: {
    position: 'absolute',
    right: 12,
    top: 12,
    fontSize: 13,
    fontWeight: '600',
    color: '#111',
  },
  summaryLoadingText: {
    marginLeft: 8,
    fontSize: 13,
    color: '#666',
  },
});