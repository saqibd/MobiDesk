// src/screens/ProductSelectScreen.tsx
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/AppNavigator';
import { getProducts, type Product } from '../services/productService';
import { setSelectedProductState } from '../state/saleSelectionStore';

type NavProp = NativeStackNavigationProp<RootStackParamList, 'ProductSelect'>;

export default function ProductSelectScreen() {
  const navigation = useNavigation<NavProp>();

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const loadProducts = async () => {
    try {
      setLoading(true);
      const data = await getProducts();
      setProducts(data);
    } catch (e) {
      console.error('Error loading products in selector', e);
      Alert.alert('Error', 'Could not load products.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const onConfirmSelection = () => {
    if (!selectedId) {
      Alert.alert('Select a product', 'Please select a product first.');
      return;
    }

    const product = products.find(p => p.id === selectedId);
    if (!product) {
      Alert.alert('Error', 'Selected product not found.');
      return;
    }

    setSelectedProductState({
      id: product.id,
      name: product.name,
      price: Number(product.price ?? 0),
      stock: Number(product.stock ?? 0),
    });

    navigation.navigate('Sales');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {loading ? (
        <View style={styles.loadingRow}>
          <ActivityIndicator size="small" />
          <Text style={styles.loadingText}>Loading products...</Text>
        </View>
      ) : products.length === 0 ? (
        <Text style={styles.emptyText}>
          No products yet. Add some from the Inventory screen.
        </Text>
      ) : (
        products.map(p => {
          const isSelected = selectedId === p.id;
          return (
            <TouchableOpacity
              key={p.id}
              style={[styles.item, isSelected && styles.itemSelected]}
              onPress={() => setSelectedId(p.id!)}
            >
              <Text style={styles.itemName}>{p.name}</Text>
              <Text style={styles.itemSub}>
                Price: {p.price} · Stock: {p.stock}
              </Text>
              {isSelected && (
                <Text style={styles.itemTag}>Selected</Text>
              )}
            </TouchableOpacity>
          );
        })
      )}

      <TouchableOpacity
        style={styles.confirmButton}
        onPress={onConfirmSelection}
      >
        <Text style={styles.confirmButtonText}>Confirm selection</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  item: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  itemSelected: {
    borderColor: '#2563eb',
  },
  itemName: {
    fontSize: 14,
    fontWeight: '600',
  },
  itemSub: {
    marginTop: 2,
    fontSize: 12,
    color: '#666',
  },
  itemTag: {
    marginTop: 4,
    fontSize: 11,
    color: '#2563eb',
  },
  confirmButton: {
    marginTop: 12,
    backgroundColor: '#2563eb',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  confirmButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 8,
    marginTop: 12,
  },
  loadingText: {
    fontSize: 13,
    color: '#444',
  },
  emptyText: {
    fontSize: 13,
    color: '#666',
    marginTop: 12,
  },
});