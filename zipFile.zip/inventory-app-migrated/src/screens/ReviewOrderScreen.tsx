// src/screens/ReviewOrderScreen.tsx
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Linking,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/AppNavigator';
import {
  getSelectedCustomerState,
  getSelectedProductState,
  resetSaleSelection,
} from '../state/saleSelectionStore';

type NavProp = NativeStackNavigationProp<RootStackParamList, 'ReviewOrder'>;

const ReviewOrderScreen: React.FC = () => {
  const navigation = useNavigation<NavProp>();

  const customer = getSelectedCustomerState();
  const product = getSelectedProductState();

  if (!customer || !product) {
    // If user somehow lands here without full selection
    return (
      <View style={[styles.container, { justifyContent: 'center' }]}>
        <Text style={styles.title}>Review Order</Text>
        <Text style={styles.warningText}>
          Please select both customer and product from Sales screen first.
        </Text>
        <TouchableOpacity
          style={styles.primaryButton}
          onPress={() => navigation.navigate('Sales')}
        >
          <Text style={styles.primaryButtonText}>Back to Sales</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const onCompleteSale = () => {
    Alert.alert(
      'Sale completed',
      `Customer: ${customer.name}\nProduct: ${product.name}\nPrice: ${product.price}`
    );
    resetSaleSelection();
    navigation.navigate('Sales');
  };

  const onCompleteSaleAndWhatsApp = async () => {
    let phone = customer.phone?.replace(/\s+/g, '') || '';
    if (!phone) {
      Alert.alert(
        'Phone required',
        'Selected customer has no phone number to send WhatsApp message.'
      );
      return;
    }

    if (phone.startsWith('0')) {
      phone = `+92${phone.slice(1)}`;
    }

    const message = `Assalam o Alaikum ${customer.name},

Aap ki sale ka detail:

Product: ${product.name}
Price: ${product.price}
Stock: ${product.stock}

Shukriya!`;

    const appUrl = `whatsapp://send?phone=${encodeURIComponent(
      phone
    )}&text=${encodeURIComponent(message)}`;

    const webUrl = `https://wa.me/${encodeURIComponent(
      phone.replace('+', '')
    )}?text=${encodeURIComponent(message)}`;

    try {
      const canOpenApp = await Linking.canOpenURL(appUrl);
      if (canOpenApp) {
        await Linking.openURL(appUrl);
      } else {
        const canOpenWeb = await Linking.canOpenURL(webUrl);
        if (canOpenWeb) {
          await Linking.openURL(webUrl);
        } else {
          Alert.alert(
            'WhatsApp not available',
            'Neither WhatsApp app nor wa.me link can be opened on this device.'
          );
          return;
        }
      }
    } catch (err) {
      console.error('Error opening WhatsApp', err);
      Alert.alert('Error', 'Could not open WhatsApp.');
      return;
    }

    // After sending, consider it completed
    resetSaleSelection();
    navigation.navigate('Sales');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Review Order</Text>
      <Text style={styles.subtitle}>
        Please review sale details before confirming.
      </Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Customer</Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{customer.name}</Text>
          {!!customer.phone && (
            <Text style={styles.cardSub}>{customer.phone}</Text>
          )}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Product</Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{product.name}</Text>
          <Text style={styles.cardSub}>Price: {product.price}</Text>
          <Text style={styles.cardSub}>Stock: {product.stock}</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Summary</Text>
        <View style={styles.card}>
          <Text style={styles.cardSub}>
            Customer: {customer.name} ({customer.phone || 'No phone'})
          </Text>
          <Text style={styles.cardSub}>
            Product: {product.name}
          </Text>
          <Text style={styles.cardSub}>
            Price: {product.price}
          </Text>
        </View>
      </View>

      <TouchableOpacity style={styles.primaryButton} onPress={onCompleteSale}>
        <Text style={styles.primaryButtonText}>Confirm Sale</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.primaryButton, styles.whatsAppButton]}
        onPress={onCompleteSaleAndWhatsApp}
      >
        <Text style={styles.primaryButtonText}>
          Confirm Sale + WhatsApp
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

export default ReviewOrderScreen;

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 32,
    flexGrow: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: '#666',
    marginBottom: 12,
  },
  warningText: {
    fontSize: 14,
    color: '#b91c1c',
    marginVertical: 12,
    textAlign: 'center',
  },
  section: {
    marginTop: 12,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 4,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#eee',
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '600',
  },
  cardSub: {
    marginTop: 2,
    fontSize: 12,
    color: '#444',
  },
  primaryButton: {
    marginTop: 24,
    backgroundColor: '#16a34a',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  whatsAppButton: {
    marginTop: 12,
    backgroundColor: '#25D366',
  },
  primaryButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
});