// src/screens/SalesScreen.tsx
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/AppNavigator';
import {
  getSelectedCustomerState,
  getSelectedProductState,
  type SelectedCustomer,
  type SelectedProduct,
  resetSaleSelection,
} from '../state/saleSelectionStore';

type NavProp = NativeStackNavigationProp<RootStackParamList, 'Sales'>;

const SalesScreen: React.FC = () => {
  const navigation = useNavigation<NavProp>();

  const [selectedCustomer, setSelectedCustomer] = useState<SelectedCustomer>(
    getSelectedCustomerState()
  );
  const [selectedProduct, setSelectedProduct] = useState<SelectedProduct>(
    getSelectedProductState()
  );

  // Refresh from store whenever Sales gains focus (handles remounts)
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      setSelectedCustomer(getSelectedCustomerState());
      setSelectedProduct(getSelectedProductState());
    });

    return unsubscribe;
  }, [navigation]);

  const openCustomerSelect = () => {
    navigation.navigate('CustomerSelect');
  };

  const openProductSelect = () => {
    navigation.navigate('ProductSelect');
  };

  const goToReviewOrder = () => {
    if (!selectedCustomer) {
      Alert.alert('Customer required', 'Please select a customer first.');
      return;
    }

    if (!selectedProduct) {
      Alert.alert('Product required', 'Please select a product first.');
      return;
    }

    navigation.navigate('ReviewOrder');
  };

  const onResetSale = () => {
    resetSaleSelection();
    setSelectedCustomer(null);
    setSelectedProduct(null);
  };

  const goToMainMenu = () => {
    navigation.navigate('Home');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>New Sale</Text>
      <Text style={styles.subtitle}>
        Select customer and products to start a sale
      </Text>

      {/* CUSTOMER SECTION */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Customer</Text>
          <TouchableOpacity onPress={openCustomerSelect}>
            <Text style={styles.linkText}>
              {selectedCustomer ? 'Change' : 'Select'}
            </Text>
          </TouchableOpacity>
        </View>

        {selectedCustomer ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{selectedCustomer.name}</Text>
            {!!selectedCustomer.phone && (
              <Text style={styles.cardSub}>{selectedCustomer.phone}</Text>
            )}
          </View>
        ) : (
          <Text style={styles.placeholderText}>
            No customer selected yet.
          </Text>
        )}
      </View>

      {/* PRODUCT SECTION */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Product</Text>
          <TouchableOpacity onPress={openProductSelect}>
            <Text style={styles.linkText}>
              {selectedProduct ? 'Change' : 'Select'}
            </Text>
          </TouchableOpacity>
        </View>

        {selectedProduct ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{selectedProduct.name}</Text>
            <Text style={styles.cardSub}>
              Price: {selectedProduct.price} · Stock: {selectedProduct.stock}
            </Text>
          </View>
        ) : (
          <Text style={styles.placeholderText}>
            No product selected yet.
          </Text>
        )}
      </View>

      {/* ACTIONS */}
      <TouchableOpacity style={styles.primaryButton} onPress={goToReviewOrder}>
        <Text style={styles.primaryButtonText}>Review Order</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.secondaryButton, { marginTop: 12 }]}
        onPress={onResetSale}
      >
        <Text style={styles.secondaryButtonText}>Reset</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.secondaryButton, { marginTop: 8 }]}
        onPress={goToMainMenu}
      >
        <Text style={styles.secondaryButtonText}>Main Menu</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

export default SalesScreen;

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 32,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: '#666',
    marginBottom: 12,
  },
  section: {
    marginTop: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '600',
  },
  linkText: {
    fontSize: 13,
    color: '#2563eb',
    fontWeight: '500',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#eee',
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '600',
  },
  cardSub: {
    marginTop: 2,
    fontSize: 12,
    color: '#666',
  },
  placeholderText: {
    fontSize: 12,
    color: '#888',
  },
  primaryButton: {
    marginTop: 24,
    backgroundColor: '#16a34a',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  secondaryButton: {
    backgroundColor: '#e5e7eb',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#111827',
    fontSize: 14,
    fontWeight: '500',
  },
});