// src/screens/CustomersScreen.tsx
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/AppNavigator';
import { getCustomers, type Customer } from '../services/customerService';

type NavProp = NativeStackNavigationProp<RootStackParamList, 'Customers'>;

const CustomersScreen: React.FC = () => {
  const navigation = useNavigation<NavProp>();

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(false);

  const loadCustomers = async () => {
    try {
      setLoading(true);
      const data = await getCustomers();
      setCustomers(data);
    } catch (e) {
      console.error('Error loading customers', e);
      Alert.alert('Error', 'Could not load customers.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', loadCustomers);
    return unsubscribe;
  }, [navigation]);

  const onAddCustomer = () => {
   navigation.navigate('AddCustomer');
  };

  const onGoToSales = (customer: Customer) => {
    navigation.navigate('Sales');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.addButton} onPress={onAddCustomer}>
        <Text style={styles.addButtonText}>+ Add Customer</Text>
      </TouchableOpacity>

      {loading ? (
        <View style={styles.loadingRow}>
          <ActivityIndicator size="small" />
          <Text style={styles.loadingText}>Loading customers...</Text>
        </View>
      ) : customers.length === 0 ? (
        <Text style={styles.emptyText}>
          No customers yet. Add some to see them here.
        </Text>
      ) : (
        customers.map(c => (
          <TouchableOpacity
            key={c.id}
            style={styles.item}
            onPress={() => onGoToSales(c)}
          >
            <Text style={styles.itemName}>{c.name}</Text>
            <Text style={styles.itemSub}>
              {c.phone || 'No phone'} · {c.city || 'City unknown'}
            </Text>
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );
};

export default CustomersScreen;

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  addButton: {
    backgroundColor: '#16a34a',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 12,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  item: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  itemName: {
    fontSize: 14,
    fontWeight: '600',
  },
  itemSub: {
    marginTop: 2,
    fontSize: 12,
    color: '#666',
  },
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 8,
    marginTop: 12,
  },
  loadingText: {
    fontSize: 13,
    color: '#444',
  },
  emptyText: {
    fontSize: 13,
    color: '#666',
    marginTop: 12,
  },
});