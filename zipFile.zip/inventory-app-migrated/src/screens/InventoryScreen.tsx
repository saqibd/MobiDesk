// src/screens/InventoryScreen.tsx
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/AppNavigator';
import { getProducts, type Product } from '../services/productService';

type NavProp = NativeStackNavigationProp<RootStackParamList, 'Inventory'>;

const InventoryScreen: React.FC = () => {
  const navigation = useNavigation<NavProp>();

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  const loadProducts = async () => {
    try {
      setLoading(true);
      const data = await getProducts();
      setProducts(data);
    } catch (e) {
      console.error('Error loading products', e);
      Alert.alert('Error', 'Could not load products.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', loadProducts);
    return unsubscribe;
  }, [navigation]);

  const onAddProduct = () => {
    navigation.navigate('AddProduct');
  };

  const onScanBarcode = () => {
    navigation.navigate('ScanBarcode');
  };

  const onGoToSalesWithProduct = (product: Product) => {
    navigation.navigate('Sales');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.row}>
        <TouchableOpacity style={styles.primaryButton} onPress={onAddProduct}>
          <Text style={styles.primaryButtonText}>+ Add Product</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.secondaryButton} onPress={onScanBarcode}>
          <Text style={styles.secondaryButtonText}>Scan Barcode</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.loadingRow}>
          <ActivityIndicator size="small" />
          <Text style={styles.loadingText}>Loading products...</Text>
        </View>
      ) : products.length === 0 ? (
        <Text style={styles.emptyText}>
          No products yet. Add some to see them here.
        </Text>
      ) : (
        products.map(p => (
          <TouchableOpacity
            key={p.id}
            style={styles.item}
            onPress={() => onGoToSalesWithProduct(p)}
          >
            <Text style={styles.itemName}>{p.name}</Text>
            <Text style={styles.itemSub}>
              Price: {p.price} · Stock: {p.stock}
            </Text>
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );
};

export default InventoryScreen;

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  row: {
    flexDirection: 'row',
    columnGap: 8,
    marginBottom: 12,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: '#16a34a',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: '#e5e7eb',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#111827',
    fontSize: 14,
    fontWeight: '500',
  },
  item: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  itemName: {
    fontSize: 14,
    fontWeight: '600',
  },
  itemSub: {
    marginTop: 2,
    fontSize: 12,
    color: '#666',
  },
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: 8,
    marginTop: 12,
  },
  loadingText: {
    fontSize: 13,
    color: '#444',
  },
  emptyText: {
    fontSize: 13,
    color: '#666',
    marginTop: 12,
  },
});