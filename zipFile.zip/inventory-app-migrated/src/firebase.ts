// src/firebase.ts
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyCFrjz0lQxA69kzXD12t9hE1Zg2LIPO7XU',
  authDomain: 'inventory-sales-manager-abe26.firebaseapp.com',
  projectId: 'inventory-sales-manager-abe26',
  storageBucket: 'inventory-sales-manager-abe26.firebasestorage.app',
  messagingSenderId: '64773131046',
  appId: '1:64773131046:web:dcc8ece740669d369ccfe7',
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);